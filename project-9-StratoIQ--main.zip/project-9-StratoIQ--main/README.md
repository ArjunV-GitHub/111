# project-9-StratoIQ-

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/ARJUN-V2005/project-9-StratoIQ-)